#!/bin/sh

THEME="KIHEO_brutalism"

echo "[1/4] Mengalihkan tema LuCI..."
ARGON_URL=$(uci -q get luci.themes.Argon)
if [ -z "$ARGON_URL" ] && [ -d /www/luci-static/argon ]; then
	ARGON_URL="/luci-static/argon"
	uci -q set luci.themes.Argon="$ARGON_URL"
fi

if [ -n "$ARGON_URL" ] && [ -d "/www${ARGON_URL}" ]; then
	echo " -> Tema Argon ditemukan ($ARGON_URL), mengalihkan ke Argon..."
	uci -q set luci.main.mediaurlbase="$ARGON_URL"
else
	echo " -> Tema Argon tidak ditemukan, mengalihkan ke tema default (Bootstrap)..."
	uci -q set luci.main.mediaurlbase='/luci-static/bootstrap'
fi

uci -q delete "luci.themes.$THEME"
uci -q commit luci

echo "[2/4] Menghapus file tema $THEME..."
rm -rf "/www/luci-static/$THEME"
rm -f "/www/luci-static/resources/menu-kiheo.js"
rm -rf "/usr/share/ucode/luci/template/themes/$THEME"

echo "[3/4] Membersihkan entri sysupgrade.conf..."
if [ -f /etc/sysupgrade.conf ]; then
	sed -i "\|/www/luci-static/$THEME|d" /etc/sysupgrade.conf
	sed -i "\|/www/luci-static/resources/menu-kiheo.js|d" /etc/sysupgrade.conf
	sed -i "\|/usr/share/ucode/luci/template/themes/$THEME|d" /etc/sysupgrade.conf
	sed -i "\|/usr/bin/KIHEO-un|d" /etc/sysupgrade.conf
	sed -i "\|/usr/bin/kiheo-brutalism-uninstall|d" /etc/sysupgrade.conf
fi

echo "[4/4] Membersihkan cache LuCI..."
rm -rf /tmp/luci-indexcache /tmp/luci-modulecache/
rm -f /usr/bin/KIHEO-un /usr/bin/kiheo-brutalism-uninstall

echo "Selesai! Tema $THEME berhasil di-uninstall."
