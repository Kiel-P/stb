#!/bin/sh
set -e

BASE_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
THEME="KIHEO_brutalism"

echo "[1/4] Menyalin aset tema $THEME..."
mkdir -p "/www/luci-static/$THEME/navbar"
mkdir -p "/www/luci-static/resources"
mkdir -p "/usr/share/ucode/luci/template/themes/$THEME"

cp -f "$BASE_DIR/www/luci-static/$THEME/cascade.css" "/www/luci-static/$THEME/"
cp -f "$BASE_DIR/www/luci-static/$THEME/login.css" "/www/luci-static/$THEME/"
cp -f "$BASE_DIR/www/luci-static/$THEME/logo.svg" "/www/luci-static/$THEME/"
cp -f "$BASE_DIR/www/luci-static/$THEME/navbar/"*.svg "/www/luci-static/$THEME/navbar/"
cp -f "$BASE_DIR/www/luci-static/resources/menu-kiheo.js" "/www/luci-static/resources/"
cp -f "$BASE_DIR/usr/share/ucode/luci/template/themes/$THEME/"*.ut "/usr/share/ucode/luci/template/themes/$THEME/"
cp -f "$BASE_DIR/uninstall.sh" /usr/bin/KIHEO-un
rm -f /usr/bin/kiheo-brutalism-uninstall

chmod 755 "/www/luci-static/$THEME" "/www/luci-static/$THEME/navbar" "/usr/share/ucode/luci/template/themes/$THEME" /usr/bin/KIHEO-un
chmod 644 "/www/luci-static/$THEME/"*.css "/www/luci-static/$THEME/"*.svg "/www/luci-static/$THEME/navbar/"*.svg "/www/luci-static/resources/menu-kiheo.js" "/usr/share/ucode/luci/template/themes/$THEME/"*.ut

echo "[2/4] Mendaftarkan dan mengaktifkan tema $THEME di UCI LuCI..."
uci -q batch <<-EOF >/dev/null
	set luci.themes.$THEME='/luci-static/$THEME'
	set luci.main.mediaurlbase='/luci-static/$THEME'
	commit luci
EOF

echo "[3/4] Menambahkan jalur tema ke /etc/sysupgrade.conf..."
if [ -f /etc/sysupgrade.conf ]; then
	sed -i "\|/usr/bin/kiheo-brutalism-uninstall|d" /etc/sysupgrade.conf
fi
for p in "/www/luci-static/$THEME" "/www/luci-static/resources/menu-kiheo.js" "/usr/share/ucode/luci/template/themes/$THEME" /usr/bin/KIHEO-un; do
	grep -qxF "$p" /etc/sysupgrade.conf 2>/dev/null || echo "$p" >> /etc/sysupgrade.conf
done

echo "[4/4] Membersihkan cache LuCI..."
rm -rf /tmp/luci-indexcache /tmp/luci-modulecache/

echo "Selesai! Tema $THEME aktif. Untuk uninstall ketik: KIHEO-un"
